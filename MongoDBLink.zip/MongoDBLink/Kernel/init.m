(* Wolfram Language Init File *)

Get[ "MongoDBLink`MongoDBLink`"]