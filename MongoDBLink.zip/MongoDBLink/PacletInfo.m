(* Paclet Info File *)

(* created 2016/12/08*)

Paclet[
    Name -> "MongoDBLink",
    Version -> "0.2.0",
    MathematicaVersion -> "6+",
    Extensions -> 
        {
            {"Documentation", Resources -> 
                {"Guides/MongoDBLink"}
            , Language -> "English"}
        }
]


